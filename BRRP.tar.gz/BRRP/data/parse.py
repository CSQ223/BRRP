 
import json

data = json.readlines('parameter.json')
